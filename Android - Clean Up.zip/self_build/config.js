const path = require('path');
const fs = require('fs');
module.exports = {
    apkjson: function () { 
        var Lang = [];
        fs.readdir(`./data/apk`, function (err, files) {
            if (err) {
                return console.log('Unable to scan directory: ' + err);
            } 
            files.forEach(function (file) {
                Lang.push(file);
            })
            const jsonContent = JSON.stringify(Lang);
            fs.writeFile("./public/json/apk.json", jsonContent, 'utf8', function (err) {
                if (err) {
                    return console.log(err);
                }
            
                load()
            }); 
        function load() {
        fs.readFile('./public/json/apk.json', (err, data) => {
           if (err) throw err;
           let student = JSON.parse(data);
            student.forEach(element => {
            var Lang = [];
            fs.readdir(`./data/apk/${element}`, function (err, files) {
            if (err) {
                return console.log('Unable to scan directory: ' + err);
            } 
            files.forEach(function (file) {
                Lang.push(file);
            })
            const jsonContent = JSON.stringify(Lang);
            fs.writeFile(`./public/json/apk/apk_${element}.json`, jsonContent, 'utf8', function (err) {
                if (err) {
                    return console.log(err);
                }
            }); 
        
        })
    });
});    
        }
        })


    },
    configjson() {
        var Lang = [];
        fs.readdir(`./public/json/preset`, function (err, files) {
            if (err) {
                return console.log('Unable to scan directory: ' + err);
            } 
            files.forEach(function (file) {
                const editedText = file.slice(0, -5)
                Lang.push(editedText);
            })
            const jsonContent = JSON.stringify(Lang);
            fs.writeFile("./public/json/preset.json", jsonContent, 'utf8', function (err) {
                if (err) {
                    return console.log(err);
                }

            }); 
    })} 



}