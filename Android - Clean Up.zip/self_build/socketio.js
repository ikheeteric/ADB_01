module.exports = {
    socket: function (callback) {
const express = require('express');
var adb = require('../platform-tools/node_adb.js');
var conf_cube = require('./conf_cube.js');
const app = express();
const http = require('http');
const server = http.createServer(app);
const { Server } = require("socket.io");
const io = new Server(server);

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

io.on('connection', (socket) => {
    function intervalFunc() {
        adb.device_scan(async function(devices) {io.emit('home', devices[0]); })
         }

        setInterval(intervalFunc,5500);

    socket.on('setups',function(data) {
      console.log(data) 
      if (data.sort == 'language') { adb.language(data.language,async function(date) {emit(date)}) }
      if (data.sort == 'apk') { apk(data) }
      if (data.sort == `setup_wifi`) {wifi(data)}
      if (data.sort == 'auto_time') {adb.auto_time(async function(date) {emit(date)}) } 
      if (data.sort == 'screentimeout') {adb.screen_timeout(data.screentimeout,async function(data) {emit(data)})}
      if (data.sort == 'screen_brightnes') {adb.screen_brightnes(async function(date) {emit(date)}) } 
      if (data.sort == 'rover_conf') {conf_cube.rover_conf(data,async function(date) {emit(date)})} 
      if (data.sort == 'cube_conf') {conf_cube.key(data,async function(date) {emit(date)})} 
      if (data.sort == 'conf_upload') {adb.upload(bestand = `../data/preset/StonexCube/.`,locatie = `/storage/emulated/0/StonexCube`,async function(date) {emit(date)})}
     });
 

     socket.on('setuplog', (msg) => {
        io.emit('setuplog', msg);
      });

      function emit(data){
        io.emit('setuplog', data);
      }
    socket.on('home_call', (msg) => {
        adb.device_scan(async function(devices) {io.emit('home', devices[0]);})
      });

      function apk(data) {
      var app = data.apk
      app.forEach(element => adb.install_apk(bestand = `../data/apk/${element}`,async function(data) {var text = `${element} Installed`; emit(text)}));
      app.forEach(element => adb.upload(bestand = `../data/apk/${element}`,locatie = `/storage/emulated/0/Download`,async function(data) {}))
      }

      function wifi(data) {
      adb.check_package(package = `com.adbwifisettingsmanager`,async function(date) {
      if (date) {
        adb.add_wifi(data.ssid,data.pass,async function(date) {emit(date)})
      } else {
      adb.install_wifi()
      adb.add_wifi(data.ssid,data.pass,async function(date) {emit(date)})
      } 
      })
      }
      function call(data) {
        console.log(data)
        adb.setup_wifi()
        adb.language(language = `${data.language}`,async function(date) {emit(date)})
        var app = data.apk
        app.forEach(element => adb.install_apk(bestand = `../data/apk/${element}`,async function(data) {var text = `${element} Installed`; emit(text)}));
        if (data.screentimeout) {adb.screen_timeout(number = data.screentimeout,async function(data) {emit(data)})}
        adb.auto_time(async function(data) {emit(data)})

    }
  });


server.listen(4000, () => {
  console.log('listening on *:3000');
}); }}