const fs = require("fs");

module.exports = { 
    rover_conf: function (datw,callback) { 
        fs.readFile('./data/preset/StonexCube_preset/Rover_conf.set', 'utf8', function (err,data) {
            if (err) {
              return console.log(err);
            }
            var result = data
            var result = result.split('<APN_Name>Input</APN_Name>').join(`<APN_Name>${datw.APN_Name}</APN_Name>`)
            var result = result.split('<Ntrip_User>Input</Ntrip_User>').join(`<Ntrip_User>${datw.Ntrip_User}</Ntrip_User>`)
            var result = result.split('<Ntrip_Password>Input</Ntrip_Password>').join(`<Ntrip_User>${datw.Ntrip_Password}</Ntrip_User>`)

        
            fs.writeFile('./data/preset/StonexCube/Import/Rover_conf.set', result, 'utf8', function (err) {
               if (err) return console.log(err);
            });
            var call = 'File created'
            callback(call)
          });
        
    },
    key: function (datw,callback) { 
      fs.readFile('./data/preset/StonexCube_preset/cube_key.TXT', 'utf8', function (err,data) {
          if (err) {
            return console.log(err);
          }
       var result = data
       var result = result.split('VERSION=CODE').join(`VERSION=${datw.version}`)
       var result = result.split('PC1=CODE').join(`PC1=${datw.pc1}`)
       var result = result.split('PC2=CODE').join(`PC2=${datw.pc2}`)
       var result = result.split('PC3=CODE').join(`PC3=${datw.pc3}`)
       var result = result.split('NAME=Referentie').join(`NAME=${datw.name}`)
       var result = result.split('SURNAME=Klantnummer').join(`SURNAME=${datw.surname}`)
console.log(result)
fs.writeFile('./data/preset/StonexCube/Import/cube_key.TXT', result, 'utf8', function (err) {
  if (err) return console.log(err);
});
          var call = 'File created'
          callback(call)
        });
      
  }



}