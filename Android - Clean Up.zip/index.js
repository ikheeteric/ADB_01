const express = require('express')
var path = require('path');
var bodyParser = require('body-parser');
const app = express();
const port = 3000;
var so = require('./self_build/socketio.js');
var config = require('./self_build/config.js');
const fs = require('fs');
config.apkjson()
config.configjson()
so.socket()
// view engine setup
app.set('views', path.join(__dirname, 'public'));
app.set('view engine', 'ejs');
//setup public folder
app.use(express.static('./public'));
// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }));

// parse application/json
app.use(bodyParser.json());



app.get('/', function(req, res) {

        res.render('pages/home',{} );

    
});

app.get('/setup/:id', function(req, res) {
    if (req.params.id == '1') {
    fs.readFile('./public/json/option.json', (err, data) => { 
        let post = JSON.parse(data);
        res.render('pages/setup',{'options' : post} );
})}

if (req.params.id == '2') {

        res.render('pages/setup2');
}


});

app.get('/setup1', function(req, res) {
        res.render('pages/setup1',{'option' : req.query.app} );
});

app.post('/test', (req,res) => {
    //Displaying the GET data in console
    console.log(req.query.test);
    res.send('Check the console');
});

app.get('/contact', function(req, res) {
    res.render('pages/contact');

});

//our alert message midleware
function messages(req,res,next){
    var message;
    res.locals.message = message;
    next();
}

app.get('/form',messages,function (req, res) {
    res.render('pages/form');
});

app.post('/form',function (req, res) {
    var message=req.body;
    res.locals.message = message;
    res.render('pages/form');
});

app.listen(port, () => console.log(`MasterEJS app Started on port ${port}!`));