var socket = io(`http://${window.location.hostname}:4000`, { transports: ['websocket', 'polling', 'flashsocket'] });
socket.on('setuplog', (message) => {melding(message)})
function melding(message) {
    console.log(message)
    let ele = document.getElementById('logging');
        ele.innerHTML += `${message}<br>`;
        makeProgress()
        document.getElementById('logging').scrollIntoView({ behavior: 'smooth', block: 'end' })
        
}


var i = 0;
var run = 0;
var bar = document.querySelector(".progress-bar");

document.getElementById("closelog").addEventListener("click", test, true);
function test(){
    bar.style.width = "0%";
    bar.innerText = "0%";
    document.getElementById('logging').innerHTML = "";
}

function makeProgress(){
    procent = document.getElementById('procent');
    run++
    

  if (procent.value == run) {
    bar.style.width = "100%";
    bar.innerText = "100%";
  } else if(i < 100){
          var value = Math.floor(procent.value)
      var pcg = Math.floor(100/value);  

      i = i + pcg;
        bar.style.width = i + "%";
        bar.innerText = i + "%";
  }
  

}



