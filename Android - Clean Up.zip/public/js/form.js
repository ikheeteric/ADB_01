var socket = io(`http://${window.location.hostname}:4000`, { transports: ['websocket', 'polling', 'flashsocket'] });
document.getElementById('submit').onclick = function() {
    asyncCall();
    check()
async function asyncCall() {
 await $("#log").modal()
 await language();
 await setup_wifi()
 await screentimeout()
 await apk();

}

$("#modal").on("hide.bs.modal", function () {
    console.log('Closed')
});


}

function check() {
    return new Promise(resolve => {
    var count = 1
    //wifi Check
    ssid_input = document.getElementById('ssid');
    pass_input = document.getElementById('wifipass');
    var ssid = ssid_input.value
    var pass = pass_input.value
    if (ssid && pass) { count++ } else {}
    //apk check
    for (var option of document.getElementById('apk').options)
    {
        if (option.selected) {
            count++
        }
    }
    //screen timeout
    if (document.getElementById('screentimeout').checked) {
        count++
    } 
    console.log(count)
    document.getElementById("procent").value = count;
    resolve('resolved');
});

}

function setup_wifi() {
    return new Promise(resolve => {
        ssid_input = document.getElementById('ssid');
        pass_input = document.getElementById('wifipass');
        var ssid = ssid_input.value
        var pass = pass_input.value
        if (ssid && pass) {
        console.log(`${ssid} ${pass}`)
        socket.emit('setups', { sort: 'setup_wifi', ssid: ssid,pass: pass });
        } else {resolve('resolved');}
    });
  }


function apk() {
    return new Promise(resolve => {
        var apk = [];
        for (var option of document.getElementById('apk').options)
        {
            if (option.selected) {
                apk.push(option.value);
                console.log(apk)
            }
        }
        socket.emit('setups', { sort: 'apk', apk: apk });
        setTimeout(() => {  resolve('resolved'); }, 10000);
    });
  }

  function language() {
    return new Promise(resolve => {
        var language = [];
        for (var option of document.getElementById('language').options)
        {
            if (option.selected) {
                language.push(option.value);
                socket.emit('setups', { sort: 'language', language: language[0] });
                socket.on('setuplog', (msg) => {
                    resolve('resolved');
                  });
            }
        }
    });
  }  

  function screentimeout() {
    return new Promise(resolve => {
        if (document.getElementById('screentimeout').checked) {
            socket.emit('setups', { sort: 'screentimeout', data: '1800000' });
            resolve('resolved');
        } else { resolve('resolved'); }
    });
  }  



  function backup() {
    return new Promise(resolve => {

      resolve('resolved');
    });
  }  

function timeout() {
    if (document.getElementById('screentimeout').checked) {
        socket.emit('setups', { sort: 'screentimeout', data: '1800000' });
    } else {
    }
}



