var socket = io('http://127.0.0.1:4000', { transports: ['websocket', 'polling', 'flashsocket'] });
document.getElementById('submit').onclick = function() {
    var language = [];
    for (var option of document.getElementById('language').options)
    {
        if (option.selected) {
            console.log(option.selected)
            language.push(option.value);
        }
    }
    apk()
    function apk() {
        var apk = [];
    for (var option of document.getElementById('apk').options)
    {
        if (option.selected) {
            apk.push(option.value);
        }
    }
    timeout(language[0],apk)
    socket.emit('setup', { language: language[0], apk: apk });
    window.location.href = "/settingup";
    
}

function timeout(language,apk) {
    if (document.getElementById('screentimeout').checked) {
        socket.emit('setup', { language: language, apk: apk,screentimeout: '1800000' });
        window.location.href = "/settingup";
    } else {
        socket.emit('setup', { language: language, apk: apk,screentimeout: '0' });
        window.location.href = "/settingup";
    }
}

}

