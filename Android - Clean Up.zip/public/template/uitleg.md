# navi.ejs
# Deze laad de navigatie bar met html code

# log.ejs
# Deze laad de content voor log

