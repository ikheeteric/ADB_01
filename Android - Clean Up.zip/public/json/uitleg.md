# Json Folder Uitleg

# Folder's
# APK [apk informatie voor select]
# preset [onze preset folder voor select]

# select word uitgelezen door
`Android\public\js_custom\zoek.js`

# File's
# apk.json [`#01`]
# preset.json [`#01`]
# option.json [`#02`]

# 01
 # Word Gebruikt om telaten zien welke files/folder we hebben

# 02
# Dit niet verwijderen!!
# Laad overige optie's in form
