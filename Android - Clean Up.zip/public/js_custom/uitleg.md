
# form.js
# Word Gebruikt om de data uit de form van de setup pagina door testuren naar de server.
# Meer Data bij pages/setup.ejs

# log.js
# Log De Form output naar de webpagina
# Meer Data bij Template/log.ejs

# preset.js 
# Laad De json bestand naar de form.

# zoek.js
# laad Al De select data in de form word gebruikt voor preset/apk's