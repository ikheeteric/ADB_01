


const activities = document.getElementById('preset');

activities.addEventListener('change', (e) => {
for (var option of document.getElementById('preset').options)
{
    if (option.selected) {
    if (option.value == 0) {} else {selected(option.value)}
    }
}

function selected(file) {
    $.getJSON(`../json/preset/${file}.json`, function(data) {  
    $('#language').selectpicker('val',data.language)
console.log(data.language)
if (data.wifi) {
    document.getElementById("ssid").value = data.wifi[0];
    document.getElementById("wifipass").value = data.wifi[1];
}
if (data.apk) {
    $('#apk').selectpicker('val', data.apk);
}

if (data.options) {
    data.options.forEach(element => {
        document.getElementById(`${element}`).checked = true;
    });
}

    })


} });



