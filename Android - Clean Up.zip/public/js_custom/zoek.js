$.getJSON(`../json/preset.json`, function(data) {
    data.forEach(element => { 
        $(`#preset`).append(`<option value="${element}">${element}</option>`);
    })
    $("#preset").selectpicker('refresh');

  })

$.getJSON(`../json/apk.json`, function(data) { 
    data.forEach(element => {
        
    $('#apk').append(`<optgroup label="${element.split('_').join(' ')}" id="${element}"></optgroup>`);
    $.getJSON(`../json/apk/apk_${element}.json`, function(datw) {  
    datw.forEach(datw => {
        console.log(`${element}/${datw}`)
    $(`#${element}`).append(`<option value="${element}/${datw}">${datw.split('_').join(' ')}</option>`);
    console.log(datw)
    })});
    });
    $("#apk").selectpicker('refresh');
    }) 


    const myTimeout = setTimeout(call2, 1000);
function call2() {   $("#apk").selectpicker('refresh');
console.log("Reload")
 }