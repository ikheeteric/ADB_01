$.getJSON(`../json/apn.json`, function(data) {
    var text = data.option
    text.forEach(element => { 
        $(`#apn_preset`).append(`<option value="${element.value}">${element.Title}</option>`);
    })
    $("#apn_preset").selectpicker('refresh');

  })
