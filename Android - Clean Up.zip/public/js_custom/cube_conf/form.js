var socket = io(`http://${window.location.hostname}:4000`, { transports: ['websocket', 'polling', 'flashsocket'] });
document.getElementById('submit').onclick = function() {
    asyncCall();
    check()
async function asyncCall() {
 await $("#log").modal()
 await rover_conf()
 await cube_conf()
 await socket.emit('setups', { sort: 'conf_upload' });


}

$("#modal").on("hide.bs.modal", function () {
    console.log('Closed')
});


}



function rover_conf() {
    return new Promise(resolve => {
        if (document.getElementById('Roverconf').checked) {
        for (var option of document.getElementById('apn_preset').options)
        {
            if (option.selected) {
               if (option.value == '0') {
                 apnname = document.getElementById('apn_al').value;
               } else {
                   apnname = option.value
               }
            
            Ntrip_User = document.getElementById('Ntrip_User').value;
            Ntrip_Password = document.getElementById('Ntrip_Password').value;
            socket.emit('setups', { sort: 'rover_conf', APN_Name: apnname,Ntrip_User: Ntrip_User,Ntrip_Password: Ntrip_Password });
            setTimeout(() => {  resolve('resolved'); }, 10000);
        } else {resolve('resolved');}}}
    });
  }  


  function cube_conf() {
    return new Promise(resolve => {
        if (document.getElementById('Cubeconf').checked) {
            
            version = document.getElementById('version').value;
            pc1 = document.getElementById('pc1').value;
            pc2 = document.getElementById('pc2').value;
            pc3 = document.getElementById('pc3').value;
            n = document.getElementById('name').value;
            surname = document.getElementById('surname').value;
            socket.emit('setups', { sort: 'cube_conf', version: version,pc1: pc1,pc2: pc2, pc3: pc3, name: n,surname: surname });
            setTimeout(() => {  resolve('resolved'); }, 10000);
        } else {resolve('resolved')}});
  }  

