const { exec } = require("child_process");
module.exports = {
    device_scan: function (callback) {
        exec("adb devices", {cwd: 'platform-tools'}, (error, stdout, stderr) => {
            
            if (error) {
                console.log(`error: ${error.message}`);
                return;
            }
            if (stderr) {
                console.log(`stderr: ${stderr}`);
                return;
            }
            var array = stdout.match(/[^\r\n]+/g);
            var theRemovedElement = array.shift();
            callback(array)
        });
    }, 

    install_apk: function (bestand,callback) {
        setTimeout(function () {
        exec(`adb install -g ${bestand}`, {cwd: 'platform-tools'}, (error, stdout, stderr) => {
            if (error) {
                console.log(`error: ${error.message}`);
            }
            if (stderr) {
            var tekst = 'Error With Installing'
            }
            if (stdout) {
                var array = stdout.match(/[^\r\n]+/g);
                var theRemovedElement = array.shift();
                var tekst = array[0]
            }
           
            callback(tekst)
        });  }, Math.floor(Math.random() * 1000));
    },
    
    upload: function (bestand,locatie,callback) {
        exec(`adb push ${bestand} ${locatie}`, {cwd: 'platform-tools'}, (error, stdout, stderr) => {
            if (error) {
                console.log(`error: ${error.message}`);
            }
            if (stderr) {
                
            }
            var log = `File Uploaded ${bestand} To ${locatie}`
            callback(log)
        });
    },

    screen_timeout: function (screentimeout,callback) {
        exec(`adb shell settings put system screen_off_timeout 1800000000`, {cwd: 'platform-tools'}, (error, stdout, stderr) => {
            if (error) {
                console.log(`error: ${error.message}`);
            }
            if (stderr) {
                console.log(stdout)
            }
            var log = `Screen Set to no Sleep`
            callback(log)
        });
    },

    screen_brightnes: function (callback) {
        exec(`adb shell settings put system screen_brightness 255`, {cwd: 'platform-tools'}, (error, stdout, stderr) => {
            if (error) {
                console.log(`error: ${error.message}`);
            }
            if (stderr) {
                console.log(stdout)
            }
            var log = `Screen brightnes to Max`
            callback(log)
        });
    },
    
    language: function (language,callback) {
        exec(`adb install ../data/basic_apk/ADB_Change_Language.apk`, {cwd: 'platform-tools'}, (error, stdout, stderr) => {
            if (error) {
                console.log(`error: ${error.message}`);
            }
            if (stderr) {
                
            }
            setTimeout(function () { permissions(language) }, 5000)  
        });
        function permissions(language) {
            exec(`adb shell pm grant net.sanapeli.adbchangelanguage android.permission.CHANGE_CONFIGURATION`, {cwd: 'platform-tools'}, (error, stdout, stderr) => {
                setTimeout(function () { taal(language) }, 5000)
            });
        }
        function taal(language) {
            exec(`adb shell am start -n net.sanapeli.adbchangelanguage/.AdbChangeLanguage -e language ${language}`, {cwd: 'platform-tools'}, (error, stdout, stderr) => {         
                setTimeout(function () { uninstall(language) }, 5000)
            });
        }
        function uninstall(language) {
            exec(`adb uninstall net.sanapeli.adbchangelanguage`, {cwd: 'platform-tools'}, (error, stdout, stderr) => {
                var log = `Language set ${language}`
                callback(log)
            });
        }
    },

//Setup Wifi Network
    add_wifi: function (ssid,password,callback) {
        exec(`adb shell am start -n com.adbwifisettingsmanager/.WifiSettingsManagerActivity --esn newConnection -e ssid ${ssid} -e password ${password}`, {cwd: 'platform-tools'}, (error, stdout, stderr) => {
            if (error) {
                console.log(`error: ${error.message}`);
            }
            if (stderr) {
                
            }
            var log = `Connected to ${ssid}`
            callback(log)
        });
    },

    //Install Apk Needed For Wifi Settings
    install_wifi: function () {
        exec(`adb install ../data/basic_apk/adb-join-wifi.apk`, {cwd: 'platform-tools'}, (error, stdout, stderr) => {
            if (error) {
                console.log(`error: ${error.message}`);
            }
            if (stderr) {
                
            }
        });
    },

        //Check If InstalledW
    check_package: function (package,callback) {
        exec(`adb shell pm list packages ${package}`, {cwd: 'platform-tools'}, (error, stdout, stderr) => {
            if (error) {
                console.log(`error: ${error.message}`);
            }
            if (stderr) {
                
            }
            callback(stdout)
        });
    },

    auto_time: function (callback) { 
        exec(`adb shell settings put global auto_time 1`, {cwd: 'platform-tools'}, (error, stdout, stderr) => {
            if (error) {
                console.log(`error: ${error.message}`);
            }
            if (stderr) {
                
            }
            var log = `Automatic Date&Time Set`
            callback(log)
        });
        exec(`adb shell settings put global auto_time_zone 1`, {cwd: 'platform-tools'}, (error, stdout, stderr) => {
            if (error) {
                console.log(`error: ${error.message}`);
            }
            if (stderr) {
                
            }
            var log = `Automatic Timezone Set`
            callback(log)
        });
        exec(`adb shell settings put system time_12_24 24`, {cwd: 'platform-tools'}, (error, stdout, stderr) => {
            if (error) {
                console.log(`error: ${error.message}`);
            }
            if (stderr) {
                
            }
            var log = `Use 24 Hour Format`
            callback(log)
        });
    }  

}