var adb = require('./node_adb.js');
adb.device_scan(async function(devices) {console.log(devices[0])})

adb.device_scan(locatie,async function(devices) {console.log(devices[0])})